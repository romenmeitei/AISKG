# AISKG ablation report

All variants use the same frozen corpus. The immutable manuscript outputs remain preserved under `outputs/legacy/`.

## Metric definitions

- Entity metrics: sentence-level canonical entity/type recovery; surface forms are used when normalization is ablated.
- Relation P/R/F1: relation label and unordered endpoint match on the held-out set.
- Exact triple accuracy: exact directed matches divided by the larger of gold and predicted set sizes.
- Directionality accuracy: correct direction among semantically matched endpoint/relation pairs.
- Pathway count: graph-consistent typed pathways reconstructed under the active support and component configuration.
- HHI and Shannon: fractional-publication concentration metrics.
- Monte Carlo robustness: mean Spearman rank agreement under Dirichlet weight perturbation.

## Summary

| label                             |   entity_precision |   entity_recall |   entity_f1 |   relation_precision |   relation_recall |   relation_f1 |   exact_triple_accuracy |   directionality_accuracy |   nodes |   edges |   density |   communities |   modularity |   largest_connected_component_fraction |   pathway_count |      hhi |   shannon |   monte_carlo_robustness |
|:----------------------------------|-------------------:|----------------:|------------:|---------------------:|------------------:|--------------:|------------------------:|--------------------------:|--------:|--------:|----------:|--------------:|-------------:|---------------------------------------:|----------------:|---------:|----------:|-------------------------:|
| Full framework                    |           0.95     |        0.84589  |    0.894928 |             1        |          0.892857 |      0.943396 |                0.892857 |                  1        |      38 |      77 | 0.0547653 |             5 |     0.330395 |                               0.947368 |              52 | 0.713098 |  0.308324 |                 0.995177 |
| Without canonical normalization   |           0.691729 |        0.630137 |    0.659498 |             0.54     |          0.482143 |      0.509434 |                0.482143 |                  1        |      67 |     135 | 0.0305292 |            10 |     0.466787 |                               0.865672 |              85 | 0.713098 |  0.308324 |                 0.993888 |
| Without ontology type constraints |           0.95     |        0.84589  |    0.894928 |             0.216981 |          0.410714 |      0.283951 |                0.150943 |                  0.695652 |      57 |     258 | 0.0808271 |             8 |     0.337225 |                               0.964912 |              44 | 0.713098 |  0.308324 |                 0.996525 |
| Without semantic quality filters  |           0.95     |        0.84589  |    0.894928 |             1        |          0.892857 |      0.943396 |                0.892857 |                  1        |      38 |      78 | 0.0554765 |             5 |     0.324787 |                               0.947368 |             105 | 0.713098 |  0.308324 |                 0.995159 |
| Without outcome-aware refinement  |           0.95     |        0.84589  |    0.894928 |             1        |          0.892857 |      0.943396 |                0.892857 |                  1        |      40 |      86 | 0.0551282 |             6 |     0.281716 |                               0.95     |              95 | 0.713098 |  0.308324 |                 0.995177 |
| Support >=1                       |           0.95     |        0.84589  |    0.894928 |             1        |          0.892857 |      0.943396 |                0.892857 |                  1        |      62 |     170 | 0.0449498 |             5 |     0.331108 |                               0.967742 |             213 | 0.713098 |  0.308324 |                 0.995177 |
| Support >=2                       |           0.95     |        0.84589  |    0.894928 |             1        |          0.892857 |      0.943396 |                0.892857 |                  1        |      38 |      77 | 0.0547653 |             5 |     0.330395 |                               0.947368 |              52 | 0.713098 |  0.308324 |                 0.995177 |
| Support >=3                       |           0.95     |        0.84589  |    0.894928 |             1        |          0.892857 |      0.943396 |                0.892857 |                  1        |      34 |      56 | 0.0499109 |             5 |     0.326579 |                               0.882353 |              22 | 0.713098 |  0.308324 |                 0.995177 |
| Support >=5                       |           0.95     |        0.84589  |    0.894928 |             1        |          0.892857 |      0.943396 |                0.892857 |                  1        |      25 |      39 | 0.065     |             3 |     0.32598  |                               1        |              14 | 0.713098 |  0.308324 |                 0.995177 |

## Changes relative to the full framework

| label                             |   entity_f1 |   relation_f1 |   exact_triple_accuracy |   nodes |   edges |   modularity |   pathway_count |
|:----------------------------------|------------:|--------------:|------------------------:|--------:|--------:|-------------:|----------------:|
| Full framework                    |    0        |      0        |                0        |       0 |       0 |  0           |               0 |
| Without canonical normalization   |   -0.235429 |     -0.433962 |               -0.410714 |      29 |      58 |  0.136392    |              33 |
| Without ontology type constraints |    0        |     -0.659446 |               -0.741914 |      19 |     181 |  0.00682999  |              -8 |
| Without semantic quality filters  |    0        |      0        |                0        |       0 |       1 | -0.00560865  |              53 |
| Without outcome-aware refinement  |    0        |      0        |                0        |       2 |       9 | -0.0486793   |              43 |
| Support >=1                       |    0        |      0        |                0        |      24 |      93 |  0.000712364 |             161 |
| Support >=2                       |    0        |      0        |                0        |       0 |       0 |  0           |               0 |
| Support >=3                       |    0        |      0        |                0        |      -4 |     -21 | -0.003816    |             -30 |
| Support >=5                       |    0        |      0        |                0        |     -13 |     -38 | -0.00441582  |             -38 |

## Interpretation

The ablations are additive robustness analyses and do not replace or modify the frozen manuscript outputs. Large losses after removal of canonical normalization or ontology constraints quantify the contribution of semantic standardization. Outcome-aware refinement removes non-terminal outcome transitions while preserving extraction benchmark performance. Support-threshold variants demonstrate the expected sparsity-coverage trade-off.